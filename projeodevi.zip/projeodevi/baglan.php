<?php
$baglan=mysqli_connect("localhost","root","","absurdemedya");

/* 
if ($baglan) {
		echo "Veritabanına baglandi";
		
}

else {"Baglanti basarisiz";

} */

?>
